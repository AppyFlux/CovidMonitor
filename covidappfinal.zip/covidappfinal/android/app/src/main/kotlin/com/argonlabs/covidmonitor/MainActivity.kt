package com.argonlabs.covidmonitor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
