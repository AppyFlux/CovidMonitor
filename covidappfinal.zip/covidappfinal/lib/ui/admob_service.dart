class AdMobService {
  String getAdMobAppId = 'ca-app-pub-1395182567884552~6834422033';

  String getBannerAppId = 'ca-app-pub-3940256099942544/6300978111';
}