import 'package:flutter/material.dart';

getPrimaryColor() {
  return Color(0xFF2E3D5F);
}

getPageBackgroundColor() {
  return Color(0xFFEEEEF3);
}

getBottomNavigationBarColor() {
  return Color(0xFFFFFFFF);
}

